'use strict';

const { WorkloadModuleBase } = require('@hyperledger/caliper-core');

class MyWorkload extends WorkloadModuleBase {
    constructor() {
        super();
    }

    async initializeWorkloadModule(workerIndex, totalWorkers, roundIndex, roundArguments, sutAdapter, sutContext) {
        await super.initializeWorkloadModule(workerIndex, totalWorkers, roundIndex, roundArguments, sutAdapter, sutContext);

        // Org名の決定
        this.orgMspId = (this.workerIndex === 0) ? 'Org1MSP' : 'Org2MSP';
        this.invoker = `User1@${this.orgMspId}`;

        for (let i = 0; i < this.roundArguments.assets; i++) {
            const assetID = `${this.orgMspId}_${this.workerIndex}_${i}`;
            console.log(`Worker ${this.workerIndex} (${this.orgMspId}): Creating asset ${assetID}`);
            const request = {
                contractId: this.roundArguments.contractId,
                contractFunction: 'CreateAsset',
                // invokerIdentity: 'User1@Org2MSP',
                invokerIdentity: this.invoker, // ここでOrgごとに分岐
                // invokerIdentity: 'User1',
                contractArguments: [assetID, 'blue', '20', 'penguin', '500'],
                targetOrganizations: [this.orgMspId],
                // targetOrganizations: 'Org2MSP',
                readOnly: false
            };

            await this.sutAdapter.sendRequests(request);
        }
    }

    async submitTransaction() {
        const randomId = Math.floor(Math.random() * this.roundArguments.assets);
        const assetID = `${this.orgMspId}_${this.workerIndex}_${randomId}`;

        const myArgs = {
            contractId: this.roundArguments.contractId,
            contractFunction: 'ReadAsset',
            invokerIdentity: this.invoker, // ここでOrgごとに分岐
            // invokerIdentity: 'User1',
            // invokerIdentity: 'User1@Org2MSP',
            contractArguments: [assetID],
            // targetOrganizations: [this.orgMspId],
            readOnly: true
        };

        await this.sutAdapter.sendRequests(myArgs);
    }

    async cleanupWorkloadModule() {
        for (let i = 0; i < this.roundArguments.assets; i++) {
            const assetID = `${this.orgMspId}_${this.workerIndex}_${i}`;
            console.log(`Worker ${this.workerIndex} (${this.orgMspId}): Deleting asset ${assetID}`);
            const request = {
                contractId: this.roundArguments.contractId,
                contractFunction: 'DeleteAsset',
                invokerIdentity: this.invoker, // ここでOrgごとに分岐
                // invokerIdentity: 'User1@Org2MSP',
                // invokerIdentity: 'User1',
                contractArguments: [assetID],
                // targetOrganizations: 'Org2MSP',
                targetOrganizations: [this.orgMspId],
                readOnly: false
            };

            await this.sutAdapter.sendRequests(request);
        }
    }
}

function createWorkloadModule() {
    return new MyWorkload();
}

module.exports.createWorkloadModule = createWorkloadModule;
