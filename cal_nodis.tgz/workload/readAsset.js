'use strict';

const { WorkloadModuleBase } = require('@hyperledger/caliper-core');

class MyWorkload extends WorkloadModuleBase {
    constructor() {
        super();
    }

    async initializeWorkloadModule(workerIndex, totalWorkers, roundIndex, roundArguments, sutAdapter, sutContext) {
        await super.initializeWorkloadModule(workerIndex, totalWorkers, roundIndex, roundArguments, sutAdapter, sutContext);

        // 環境変数からOrgを決定（デフォルト: Org1MSP）
        this.orgMspId = process.env.ORG || 'Org1MSP';
        this.invoker = `User1@${this.orgMspId}`;

        for (let i = 0; i < this.roundArguments.assets; i++) {
            const assetID = `${this.orgMspId}_${workerIndex}_${i}`;
            console.log(`Worker ${workerIndex} (${this.orgMspId}): Creating asset ${assetID}`);
            const request = {
                contractId: this.roundArguments.contractId,
                contractFunction: 'CreateAsset',
                invokerIdentity: this.invoker,
                contractArguments: [assetID, 'blue', '20', 'penguin', '500'],
                targetOrganizations: [this.orgMspId],
                readOnly: false
            };

            await this.sutAdapter.sendRequests(request);
        }
    }

    async submitTransaction() {
        const randomId = Math.floor(Math.random() * this.roundArguments.assets);
        const assetID = `${this.orgMspId}_${this.workerIndex}_${randomId}`;

        const request = {
            contractId: this.roundArguments.contractId,
            contractFunction: 'ReadAsset',
            invokerIdentity: this.invoker,
            contractArguments: [assetID],
            readOnly: true
        };

        await this.sutAdapter.sendRequests(request);
    }

    async cleanupWorkloadModule() {
        for (let i = 0; i < this.roundArguments.assets; i++) {
            const assetID = `${this.orgMspId}_${this.workerIndex}_${i}`;
            console.log(`Worker ${this.workerIndex} (${this.orgMspId}): Deleting asset ${assetID}`);
            const request = {
                contractId: this.roundArguments.contractId,
                contractFunction: 'DeleteAsset',
                invokerIdentity: this.invoker,
                contractArguments: [assetID],
                targetOrganizations: [this.orgMspId],
                readOnly: false
            };

            await this.sutAdapter.sendRequests(request);
        }
    }
}

function createWorkloadModule() {
    return new MyWorkload();
}

module.exports.createWorkloadModule = createWorkloadModule;
