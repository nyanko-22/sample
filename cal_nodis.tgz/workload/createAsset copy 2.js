'use strict';

const { WorkloadModuleBase } = require('@hyperledger/caliper-core');

class MyWorkload extends WorkloadModuleBase {
    constructor() {
        super();
        this.txIndex = -1;
        this.colors = ['red', 'blue', 'green', 'black', 'white', 'pink', 'rainbow'];
        this.owners = ['Alice', 'Bob', 'Claire', 'David'];
    }

    async initializeWorkloadModule(workerIndex, totalWorkers, roundIndex, roundArguments, sutAdapter, sutContext) {
        await super.initializeWorkloadModule(workerIndex, totalWorkers, roundIndex, roundArguments, sutAdapter, sutContext);
        
        // WorkerごとにOrgを設定
        this.orgMspId = (this.workerIndex === 0) ? 'Org1MSP' : 'Org2MSP';
        this.invoker = `User1@${this.orgMspId}`;
    }

    async submitTransaction() {
        this.txIndex++;

        const assetID = `${this.orgMspId}_${this.roundIndex}_${this.workerIndex}_${this.txIndex}_${Date.now()}`;
        const color = this.colors[this.txIndex % this.colors.length];
        const size = (((this.txIndex % 10) + 1) * 10).toString();
        const owner = this.owners[this.txIndex % this.owners.length];
        const appraisedValue = Math.floor(Math.random() * (1000 - 200 + 1) + 200);

        const request = {
            contractId: this.roundArguments.contractId,
            contractFunction: 'CreateAsset',
            // invokerIdentity: "User1@Org1MSP",
            // invokerIdentity: this.invoker, // ここでOrgごとに分岐
            invokerIdentity: 'User1',
            contractArguments: [assetID, color, size, owner, appraisedValue],
            readOnly: false,
            // targetOrganizations: 'Org1MSP'
            // targetOrganizations: [this.orgMspId]  // ★ ここが重要
        };

        console.info(`[${this.orgMspId}] TX #${this.txIndex}: CreateAsset(${assetID})`);
        await this.sutAdapter.sendRequests(request);
    }
}

function createWorkloadModule() {
    return new MyWorkload();
}

module.exports.createWorkloadModule = createWorkloadModule;
