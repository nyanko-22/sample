import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as s3 from 'aws-cdk-lib/aws-s3';

interface CaliperS3StackProps extends cdk.StackProps {
  bucketName: string;
}

export class CaliperS3Stack extends cdk.Stack {
  constructor(scope: Construct, id: string, props: CaliperS3StackProps) {
    super(scope, id, props);

    const bucket = new s3.Bucket(this, 'CaliperBucket', {
      bucketName: props.bucketName,
      versioned: true,
      encryption: s3.BucketEncryption.S3_MANAGED,
      blockPublicAccess: s3.BlockPublicAccess.BLOCK_ALL,
      removalPolicy: cdk.RemovalPolicy.DESTROY,
      autoDeleteObjects: true
    });

    new cdk.CfnOutput(this, 'BucketName', {
      value: bucket.bucketName
    });

    new cdk.CfnOutput(this, 'BucketArn', {
      value: bucket.bucketArn
    });
  }
}
