import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as efs from 'aws-cdk-lib/aws-efs';
import * as ec2 from 'aws-cdk-lib/aws-ec2';

interface CaliperEfsStackProps extends cdk.StackProps {
  vpcId: string;
  privateSubnetIds: string[];
  securityGroupId: string;
  fileSystemName: string;
}

export class CaliperEfsStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props: CaliperEfsStackProps) {
    super(scope, id, props);

    const vpc = ec2.Vpc.fromVpcAttributes(this, 'VPC', {
      vpcId: props.vpcId,
      availabilityZones: cdk.Stack.of(this).availabilityZones,
      privateSubnetIds: props.privateSubnetIds,
    });

    const sg = ec2.SecurityGroup.fromSecurityGroupId(this, 'EfsSG', props.securityGroupId);

    const fileSystem = new efs.FileSystem(this, 'CaliperEFS', {
      vpc,
      vpcSubnets: { subnets: props.privateSubnetIds.map(id => ec2.Subnet.fromSubnetId(this, `Subnet-${id}`, id)) },
      securityGroup: sg,
      encrypted: true,
      fileSystemName: props.fileSystemName,
      lifecyclePolicy: efs.LifecyclePolicy.AFTER_7_DAYS,
      removalPolicy: cdk.RemovalPolicy.DESTROY,
    });

    new cdk.CfnOutput(this, 'FileSystemId', { value: fileSystem.fileSystemId });
    new cdk.CfnOutput(this, 'FileSystemArn', { value: fileSystem.fileSystemArn });
  }
}
