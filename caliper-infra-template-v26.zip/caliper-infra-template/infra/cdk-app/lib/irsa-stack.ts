import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as eks from 'aws-cdk-lib/aws-eks';

interface IrsaStackProps extends cdk.StackProps {
  clusterName: string;
  namespace: string;
  serviceAccountName: string;
  policyArns: string[];
}

export class IrsaStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props: IrsaStackProps) {
    super(scope, id, props);

    const cluster = eks.Cluster.fromClusterAttributes(this, 'EksCluster', {
      clusterName: props.clusterName,
      kubectlRoleArn: `arn:aws:iam::\${cdk.Stack.of(this).account}:role/Admin`,
      openIdConnectProvider: eks.OpenIdConnectProvider.fromOpenIdConnectProviderArn(
        this,
        'OIDCProvider',
        `arn:aws:iam::\${cdk.Stack.of(this).account}:oidc-provider/oidc.eks.\${cdk.Stack.of(this).region}.amazonaws.com/id/\${this.node.tryGetContext('oidcId')}`
      )
    });

    const irsaRole = new iam.Role(this, 'CaliperIRSA', {
      assumedBy: new iam.WebIdentityPrincipal(cluster.openIdConnectProvider.openIdConnectProviderArn, {
        StringEquals: {
          [`oidc.eks.\${cdk.Stack.of(this).region}.amazonaws.com/id/\${this.node.tryGetContext('oidcId')}:sub`]:
            `system:serviceaccount:\${props.namespace}:\${props.serviceAccountName}`
        }
      }),
      description: 'IRSA role for Caliper Pod'
    });

    props.policyArns.forEach((arn, i) => {
      irsaRole.addManagedPolicy(iam.ManagedPolicy.fromAwsManagedPolicyName(arn));
    });

    new cdk.CfnOutput(this, 'IrsaRoleArn', { value: irsaRole.roleArn });
  }
}
