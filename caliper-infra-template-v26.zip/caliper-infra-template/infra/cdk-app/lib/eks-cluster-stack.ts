import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as eks from 'aws-cdk-lib/aws-eks';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as iam from 'aws-cdk-lib/aws-iam';

interface EksClusterStackProps extends cdk.StackProps {
  vpcId: string;
  privateSubnetIds: string[];
  clusterName: string;
}

export class EksClusterStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props: EksClusterStackProps) {
    super(scope, id, props);

    const vpc = ec2.Vpc.fromVpcAttributes(this, 'ImportedVPC', {
      vpcId: props.vpcId,
      availabilityZones: cdk.Stack.of(this).availabilityZones,
      privateSubnetIds: props.privateSubnetIds,
    });

    const clusterAdmin = new iam.Role(this, 'AdminRole', {
      assumedBy: new iam.AccountRootPrincipal()
    });

    const cluster = new eks.Cluster(this, 'CaliperEKSCluster', {
      vpc,
      vpcSubnets: [{ subnets: props.privateSubnetIds.map(id => ec2.Subnet.fromSubnetId(this, `Subnet-${id}`, id)) }],
      defaultCapacity: 0,
      version: eks.KubernetesVersion.V1_29,
      clusterName: props.clusterName,
      mastersRole: clusterAdmin,
      endpointAccess: eks.EndpointAccess.PRIVATE
    });

    cluster.addNodegroupCapacity('DefaultNodeGroup', {
      nodegroupName: 'caliper-ng',
      desiredSize: 2,
      minSize: 1,
      maxSize: 4,
      instanceTypes: [new ec2.InstanceType('t3.medium')],
      subnets: { subnets: props.privateSubnetIds.map(id => ec2.Subnet.fromSubnetId(this, `NGSubnet-${id}`, id)) }
    });

    new cdk.CfnOutput(this, 'ClusterName', {
      value: cluster.clusterName
    });
  }
}
