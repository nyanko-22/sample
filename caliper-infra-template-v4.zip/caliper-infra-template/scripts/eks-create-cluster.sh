#!/bin/bash
# scripts/eks-create-cluster.sh

CLUSTER_NAME=caliper-cluster
REGION=ap-northeast-1
NODE_TYPE=t3.large
NODE_COUNT=3

echo "🚀 Creating EKS cluster: $CLUSTER_NAME in $REGION..."

eksctl create cluster \
  --name $CLUSTER_NAME \
  --region $REGION \
  --version 1.29 \
  --nodegroup-name caliper-nodes \
  --node-type $NODE_TYPE \
  --nodes $NODE_COUNT \
  --nodes-min 1 \
  --nodes-max 5 \
  --managed

echo "✅ EKS Cluster created: $CLUSTER_NAME"
