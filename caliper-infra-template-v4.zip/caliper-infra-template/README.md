# Caliper Infra Template for EKS

このテンプレートは、Amazon EKS 上で Hyperledger Fabric の大規模負荷試験を行うための Caliper 環境を構築・実行・レポート取得・クリーンアップする一連のファイルを提供します。

---

## 📁 ディレクトリ構成

```
caliper-infra-template/
├── k8s/                         # PVC や EFS マウント用Podのマニフェスト
├── caliper-worker-chart/       # Caliper Worker 用 Helm チャート
│   ├── templates/
│   └── values-orgs/            # org001〜org100 の上書き values ファイル
├── caliper-manager-chart/      # Caliper Manager 用 Helm チャート
│   └── templates/
├── configs/                    # 各 org の設定 (networkConfig.yaml, walletなど)
├── benchmarks/                 # Caliper シナリオ (benchmark.yaml 等)
├── scripts/                    # セットアップ・実行・削除スクリプト
```

---

## 🚀 使用手順

### 1. EFS CSI DriverとPVCの準備

```bash
cd scripts
./1-4_setup.sh
```

- EFS CSIドライバのインストール
- `caliper-config-pvc` の作成
- `init-efs-uploader` Podを通じて `configs/` と `benchmarks/` をEFSにアップロード

---

### 2. Caliper Worker（100組織分）のデプロイ

```bash
./5-6_deploy-workers.sh
```

- Helm を使って org001〜org100 の Worker Job をデプロイ

---

### 3. Caliper Manager の起動

```bash
./7_deploy-manager.sh
```

- Caliper CLI を使って負荷試験を実行

---

### 4. レポートの取得

```bash
./8_fetch-report.sh
```

- `report.html` をローカルに保存（自動で日付付き）

---

### 5. クリーンアップ（WorkerとManagerの削除）

```bash
./9_cleanup.sh
```

---

## 🔧 カスタマイズポイント

- `caliper-worker-chart/values-orgs/orgXXX.yaml` に個別のORG設定を追加
- `caliper-manager-chart/values.yaml` で対象ORGやbenchmarkファイルを指定
- `configs/orgXXX/` に `networkConfig.yaml`, `wallet`, `ccp.yaml` などを配置

---

## 📦 依存環境

- Helm 3.x
- kubectl
- EKS（EFS CSI driver導入済み）
- EFS (ReadWriteManyでPVC共有)

---

## 📬 サポート

このテンプレートは、100組織規模のFabricネットワークにCaliperを使ったベンチマークを実施する目的で作られています。必要に応じてさらに自動化（Argo, GitHub Actions）やレポートのS3保存にも拡張可能です。
