# Caliper Infra Template for EKS

このテンプレートは、Amazon EKS 上で Hyperledger Fabric の大規模負荷試験を行うための Caliper 環境を構築・実行・レポート取得・クリーンアップする一連のファイルを提供します。

---

## 📁 ディレクトリ構成

```
caliper-infra-template/
├── k8s/                         # PVC や EFS マウント用Podのマニフェスト
├── caliper-worker-chart/       # Caliper Worker 用 Helm チャート
│   ├── templates/
│   └── values-orgs/            # org001〜org100 の上書き values ファイル
├── caliper-manager-chart/      # Caliper Manager 用 Helm チャート
│   └── templates/
├── configs/                    # 各 org の設定 (networkConfig.yaml, walletなど)
├── benchmarks/                 # Caliper シナリオ (benchmark.yaml 等)
├── monitoring/                 # Prometheus / Grafana 設定
├── scripts/                    # セットアップ・実行・削除スクリプト
```

---

## 🚀 実行手順（フル自動化）

以下の順番でスクリプトを実行してください：

```bash
cd scripts/

# ① Amazon EFS の作成
./eks-create-efs.sh

# ② EKS クラスタの作成
./eks-create-cluster.sh

# ③ 監視環境（Prometheus / Grafana）のセットアップ
./0-monitoring-setup.sh

# ④ PVC作成 + Caliper設定ファイルのアップロード（EFSへ）
./1-4_setup.sh

# ⑤ Caliper Worker（100組織分）のデプロイ
./5-6_deploy-workers.sh

# ⑥ Caliper Manager のデプロイ（負荷試験の実行）
./7_deploy-manager.sh

# ⑦ 負荷試験レポートの取得（report.html）
./8_fetch-report.sh

# ⑧ クリーンアップ（Worker, Manager の削除）
./9_cleanup.sh
```

---

## 📊 Grafana ダッシュボード

- Grafana は NodePort 32000 番でアクセス可能（パスワード `admin`）
- Caliper TPS / ノードリソース / コンテナ使用量などを可視化

---

## 📦 依存ツール

- `eksctl`
- `kubectl`
- `helm`
- `aws` CLI
- EKS & EFS が利用可能な AWS アカウント

---

## 🛠 拡張のヒント

- S3へのレポート自動保存
- Argo Workflows によるCI化
- 各ORGごとのGrafanaダッシュボード分離表示

---



---

## 🔐 VPC セキュリティグループ連携と接続確認

### 1. セキュリティグループ連携（双方向）

```bash
cd scripts/
./efs-authorize-sg.sh
```

- `FABRIC_SG_ID` に、Fabricノードが属するSGを設定してください。
- CaliperクラスターとFabricノード間の**双方向通信（全ポート）**が許可されます。

### 2. Caliperノード → Fabricノード 接続確認

```bash
./caliper-test-connection.sh
```

- `FABRIC_PEER_HOST` に、Fabric PeerのVPC内ホスト名 or IP を指定してください。
- ポート7051などが開通しているかを `nc` で確認します。

---


---

## ☁️ S3へのレポートアップロード

試験レポートをS3バケットに保存するには以下を実行：

```bash
cd scripts/
./10_upload-report-to-s3.sh
```

- `your-s3-bucket-name` にアップロード先バケット名を設定してください
- 保存先パスは：`s3://<bucket>/caliper-reports/manager/report-YYYYMMDD-HHmmss.html`

AWS CLIが必要です。事前に`aws configure`などで認証設定してください。

---


---

## 🔗 MQTTブローカーとの連携（Caliper Manager & Worker）

### Mosquitto デプロイ

以下を適用して MQTT ブローカー（Mosquitto）を起動：

```bash
kubectl apply -f k8s/mosquitto.yaml
```

- サービス名：`mosquitto`
- ポート：1883
- Caliper の manager / worker は `mqtt://mosquitto:1883` を使って連携

マニフェスト修正済みのため、Helmチャートから起動すれば MQTT 連携済みの状態になります。

---

---

## 🗺️ 全体構成図

以下は、このテンプレートによって構築される Caliper + Fabric 負荷試験環境の構成図です：

![Caliper EKS Architecture](./assets/architecture.png)

---

### 🔍 構成要素の解説

#### 1. Hyperledger Fabric（既存VPC側）

- **Fabric Orderer / Peer**：既存のVPCにすでに展開されているFabricネットワーク。
- **gRPC通信**：CaliperからFabricへはgRPC経由でトランザクション送信を行う。

#### 2. Amazon EKS（Caliperクラスタ）

- **Caliper Manager Pod**：
  - ベンチマーク定義（benchmark.yaml）に従って全体試験を制御
  - MQTTブローカーを介して各Workerへ負荷指示を送信

- **Caliper Worker Pod (x100)**：
  - 各WorkerはORG単位で分割され、指定されたnetworkConfig.yamlを用いてFabric Peerと通信
  - 同じEFSをマウントして設定ファイルを共有

- **Amazon EFS**：
  - ManagerとWorkerの設定やWalletなどの共有領域として使用
  - Workerは自分に必要なnetworkConfig.yamlを動的に選択

- **Mosquitto（MQTT Broker）**：
  - ManagerとWorker間の連携に使用される軽量ブローカー

#### 3. Monitoring（監視）

- **Node Exporter (DaemonSet)**：
  - 各ノード上のCPU, メモリ, ネットワーク使用状況をPrometheusへ送信

- **Prometheus**：
  - Caliperのメトリクス、Node Exporterの情報を収集
  - ORG単位で `org="orgXYZ"` というラベルを付与

- **Grafana**：
  - ORGごとのTPSやリソース消費を行別に可視化したダッシュボードを提供

---

---

## 🗺️ テキストベース構成図（Caliper × EKS × Fabric）

```text
                                 ┌────────────────────────────┐
                                 │   Hyperledger Fabric VPC   │
                                 │                            │
                                 │  ┌────────┐   ┌─────────┐  │
                                 │  │ Peer1  │...│ Peer100 │  │
                                 │  └────────┘   └─────────┘  │
                                 │                            │
                                 └──────▲─────────────▲───────┘
                                        │gRPC        │gRPC
                                        │            │
              ┌─────────────────────────┴────────────┴────────────────────────┐
              │                     Amazon EKS クラスター                      │
              │                                                                │
              │  ┌────────────────────────────────────────────────────────┐   │
              │  │                       Caliper Manager                  │   │
              │  │ - benchmark.yaml 読み込み                              │   │
              │  │ - MQTT 経由でWorkerに負荷指示送信                     │   │
              │  └────────────────────────────────────────────────────────┘   │
              │                      ▲                     ▲                  │
              │                      │ MQTT                │ MQTT              │
              │  ┌───────────────────┴────┐     ┌──────────┴────────────────┐│
              │  │ Caliper Worker Pod ①   │ ... │ Caliper Worker Pod 100   ││
              │  │ --caliper-workerid=org001   │ --caliper-workerid=org100 ││
              │  │ --networkConfig=efs/...     │ --networkConfig=efs/...   ││
              │  └─────────────────────────────┘     └──────────────────────┘│
              │                                                                │
              │  ┌──────────────────────────────────────────────────────────┐  │
              │  │                      Mosquitto (MQTT Broker)            │  │
              │  └──────────────────────────────────────────────────────────┘  │
              │                                                                │
              │  ┌───────────────┐    ┌──────────────┐    ┌────────────────┐  │
              │  │ Node Exporter │    │  Prometheus  │    │    Grafana     │  │
              │  └───────────────┘    └──────┬───────┘    └─────┬──────────┘  │
              │                              │                   │             │
              └──────────────────────────────┴───────────────────┴─────────────┘
                                                        メトリクス + ダッシュボード
```

---


---

## 📊 Kubernetes ダッシュボードの導入・利用手順

Amazon EKSクラスターに Kubernetes ダッシュボードを導入して、PodやJob、リソース使用状況を GUI で確認することができます。

### ① ダッシュボードをデプロイ

以下のコマンドで Kubernetes Dashboard をデプロイしてください：

```bash
kubectl apply -f https://raw.githubusercontent.com/kubernetes/dashboard/v2.7.0/aio/deploy/recommended.yaml
```

または、インターネット接続が制限されている環境ではローカルに保存して適用します：

```bash
curl -LO https://raw.githubusercontent.com/kubernetes/dashboard/v2.7.0/aio/deploy/recommended.yaml
kubectl apply -f recommended.yaml
```

### ② 管理者権限のサービスアカウントを作成

テンプレートに含まれる以下のRBACファイルを適用：

```bash
kubectl apply -f k8s/dashboard-admin-user.yaml
```

### ③ ポートフォワーディングでアクセス

以下のコマンドでローカルアクセス用ポートを開きます：

```bash
kubectl -n kubernetes-dashboard port-forward svc/kubernetes-dashboard 8443:443
```

その後、以下のURLにアクセス：

📎 [https://localhost:8443](https://localhost:8443)

### ④ ログイントークンの取得

```bash
kubectl -n kubernetes-dashboard create token admin-user
```

出力されたトークンをコピーして、ブラウザのダッシュボードログイン画面で「トークン」モードを選び貼り付けてください。

---



---

## 🧪 Kubernetes ダッシュボード（開発用スキップログインモード）

開発環境向けに、認証なしでダッシュボードにアクセスできるモードです。

### デプロイ

```bash
kubectl apply -f k8s/kubernetes-dashboard-skip-login.yaml
```

### アクセス

```bash
kubectl -n kubernetes-dashboard port-forward svc/kubernetes-dashboard 8443:443
```

アクセスURL: [https://localhost:8443](https://localhost:8443)

🔒 このモードでは誰でもダッシュボードにアクセスできるため、本番環境には**絶対に使用しないでください**。

---



---

## 📈 Grafana にアクセスする（ポートフォワード）

以下のスクリプトを使って、Grafana のポートフォワードを自動で実行できます：

```bash
cd scripts/
./99_port-forward-grafana.sh
```

成功すると `http://localhost:3000` でアクセスできます。

> ※ `monitoring` Namespace または `default` Namespace に Grafana が存在する必要があります。

初期ログイン：
- ユーザー名：`admin`
- パスワード：`admin` または `prom-operator`

---


---

## 🐳 Caliper カスタムイメージの作成とECRデプロイ

### ① Dockerfile の構成

`docker/Dockerfile` を編集すれば、任意のnpmパッケージやカスタムスクリプトを追加できます。

### ② カスタムイメージをECRにPush

```bash
cd scripts/
./98_build-and-push-ecr.sh
```

成功すると、以下のようなECRイメージが作成されます：

```
<account_id>.dkr.ecr.ap-northeast-1.amazonaws.com/caliper-custom:latest
```

### ③ Helm values.yaml に指定

```yaml
image: <account_id>.dkr.ecr.ap-northeast-1.amazonaws.com/caliper-custom:latest
```

必要に応じて `imagePullSecrets` や IAM Role for Service Account（IRSA）を併用してください。

---



---

## 🌐 NAT Gatewayによる外部インターネットアクセスの許可（オプション）

クラスターのPodがインターネットへアクセスする必要がある場合（例：npm install, Docker pullなど）、
`privateNetworking: true` 構成のままで NAT Gateway を構成できます。

### 有効化方法

Terraform 実行時に `enable_nat_gateway` を `true` に指定：

```bash
terraform apply -var="enable_nat_gateway=true"
```

- NAT Gatewayは**パブリックサブネットに配置**され、**プライベートサブネットのPodから外部通信が可能**になります。
- デフォルトではコスト削減のため無効です。

---


---

## 🌐 NAT Gateway 構成（CDK版）

`infra/cdk-nat-gateway/` 以下に、既存のVPC/Subnetに NAT Gateway を構成する AWS CDK プロジェクトがあります。

### 使い方

```bash
cd infra/cdk-nat-gateway/
npm install
npm run build

# VPC/Subnet情報を渡してデプロイ
cdk deploy --context vpcId=vpc-xxxxxxxx            --context publicSubnetId=subnet-aaaaaaa            --context privateSubnetIds='["subnet-bbbbbbb","subnet-ccccccc"]'
```

> NAT Gateway は VPCのパブリックサブネットに配置され、プライベートサブネットのルートテーブルが自動設定されます。

---


---

## ☸️ EKSクラスタ構成（CDK版）

`infra/cdk-eks-cluster/` 以下に、既存のVPCに Caliper 用 EKS クラスタを構成する AWS CDK プロジェクトがあります。

### 使い方

```bash
cd infra/cdk-eks-cluster/
npm install
npm run build

cdk deploy --context vpcId=vpc-xxxxxxxx            --context privateSubnetIds='["subnet-xxxxxx","subnet-yyyyyy"]'            --context clusterName=caliper-cluster
```

- クラスタは **private endpoint only（外部非公開）**
- Node Group は `t3.medium` インスタンスで 2台（min=1, max=4）

---


---

## 🔐 IRSA対応（IAM Role for ServiceAccount）

CaliperのPodにS3などのAWSサービスへのアクセス権限を付与するために、IRSA構成をCDKで提供しています。

### 📁 パス：`infra/cdk-irsa/`

### ⚙️ 必要情報

- EKSクラスタ名
- OIDCプロバイダーID（例: `EXAMPLED539D4633E53DE1B716D3041E`）
- 対象のNamespace / ServiceAccount名（例: caliper / manager）

### 🚀 デプロイ手順

```bash
cd infra/cdk-irsa/
npm install
npm run build

cdk deploy --context clusterName=caliper-cluster \
           --context oidcId=EXAMPLED539D4633E53DE1B716D3041E \
           --context namespace=caliper \
           --context serviceAccountName=manager
```

### 🧩 Helmと連携する例

Helmの `values.yaml` に以下を指定：

```yaml
serviceAccount:
  create: true
  name: manager
  annotations:
    eks.amazonaws.com/role-arn: arn:aws:iam::<ACCOUNT_ID>:role/CaliperIRSAStack-CaliperIRSA...
```

---



---

## 📂 EFS作成（CDK）

EFS（Elastic File System）を作成するための CDK スタックは `infra/cdk-efs/` にあります。

### 🚀 実行コマンド

```bash
cd infra/cdk-efs/
npm install
npm run build

cdk deploy --context vpcId=vpc-xxxxxxxx \
           --context privateSubnetIds='["subnet-xxxx","subnet-yyyy"]' \
           --context securityGroupId=sg-zzzzzzzz \
           --context fileSystemName=caliper-efs
```

> VPC、プライベートサブネット、SG は Caliperクラスタと共通のものを指定してください。

---



---

## 🪣 S3バケット作成（CDK）

Caliperレポートなどを保存するためのS3バケットを作成できます。

### 📁 パス：`infra/cdk-s3/`

### 🚀 実行コマンド

```bash
cd infra/cdk-s3/
npm install
npm run build

cdk deploy --context bucketName=caliper-report-bucket
```

- バージョニング有効
- 暗号化（S3 managed）
- 公開ブロック＆削除可能な環境（開発用）

---



---

# 🚀 CDKによるインフラ構築手順（EKS / EFS / S3 / IRSA / NAT）

Caliper用のインフラは、すべてAWS CDK（TypeScript）で自動構築できます。

## 🔧 事前準備

```bash
npm install -g aws-cdk
```

## 📁 デプロイ構成一覧

| 機能         | ディレクトリ                     | 概要                        |
|--------------|----------------------------------|-----------------------------|
| EKSクラスタ   | `infra/cdk-eks-cluster/`         | EKS + ノードグループ         |
| EFS構成      | `infra/cdk-efs/`                 | 永続ボリューム                |
| S3構成       | `infra/cdk-s3/`                  | レポート格納バケット         |
| IRSA構成     | `infra/cdk-irsa/`                | IAM Role for SA + OIDC       |
| NAT Gateway  | `infra/cdk-nat-gateway/`         | 外部インターネット通信用     |

---

## ✅ CDKデプロイ共通の流れ

```bash
cd infra/cdk-<component>/
npm install
npm run build

cdk deploy --context <パラメータ>=<値> ...
```

各コンポーネントはそれぞれ独立してデプロイできます。

---

## 🧪 実行例：EKSクラスタの構築

```bash
cd infra/cdk-eks-cluster/
cdk deploy --context vpcId=vpc-xxxxxx \
           --context privateSubnetIds='["subnet-aaa","subnet-bbb"]' \
           --context clusterName=caliper-cluster
```

## 🪣 実行例：S3作成

```bash
cd infra/cdk-s3/
cdk deploy --context bucketName=caliper-report-bucket
```

## 📂 実行例：EFS作成

```bash
cd infra/cdk-efs/
cdk deploy --context vpcId=vpc-xxxx \
           --context privateSubnetIds='["subnet-xxx"]' \
           --context securityGroupId=sg-zzzzzzzz
```

## 🔐 実行例：IRSA（Caliper Manager用）

```bash
cd infra/cdk-irsa/
cdk deploy --context clusterName=caliper-cluster \
           --context oidcId=EXAMPLED539... \
           --context namespace=caliper \
           --context serviceAccountName=manager
```

---

## 🛰 実行例：NAT Gateway

```bash
cd infra/cdk-nat-gateway/
cdk deploy --context vpcId=vpc-xxxx \
           --context publicSubnetId=subnet-aaa \
           --context privateSubnetIds='["subnet-bbb"]'
```

> NAT Gateway はコストがかかるため、不要時は削除してください。

---
