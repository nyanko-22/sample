#!/bin/bash
set -e
mkdir -p report deploy_history

log_file=deploy_log.txt
csv_file=deploy_time.csv
echo "Step,Duration(s)" > $csv_file

function run_step() {
    step_name=$1
    script_path=$2

    echo "▶ [$step_name] START $(date)" | tee -a $log_file
    start=$(date +%s)
    bash "$script_path"
    end=$(date +%s)
    duration=$((end - start))
    echo "✅ [$step_name] DONE in ${duration}s" | tee -a $log_file
    echo "${step_name},${duration}" >> $csv_file
    echo "" | tee -a $log_file
}

for script in deploy_scripts/*.sh; do
    step=$(basename "$script")
    run_step "$step" "$script"
done

python3 generate_report.py
