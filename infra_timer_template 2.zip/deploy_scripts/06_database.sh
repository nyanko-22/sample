#!/bin/bash
echo 'Running 06_database.sh...'
sleep 17