#!/bin/bash
echo 'Simulating deployment...'
sleep 2