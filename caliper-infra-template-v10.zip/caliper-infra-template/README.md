# Caliper Infra Template for EKS

このテンプレートは、Amazon EKS 上で Hyperledger Fabric の大規模負荷試験を行うための Caliper 環境を構築・実行・レポート取得・クリーンアップする一連のファイルを提供します。

---

## 📁 ディレクトリ構成

```
caliper-infra-template/
├── k8s/                         # PVC や EFS マウント用Podのマニフェスト
├── caliper-worker-chart/       # Caliper Worker 用 Helm チャート
│   ├── templates/
│   └── values-orgs/            # org001〜org100 の上書き values ファイル
├── caliper-manager-chart/      # Caliper Manager 用 Helm チャート
│   └── templates/
├── configs/                    # 各 org の設定 (networkConfig.yaml, walletなど)
├── benchmarks/                 # Caliper シナリオ (benchmark.yaml 等)
├── monitoring/                 # Prometheus / Grafana 設定
├── scripts/                    # セットアップ・実行・削除スクリプト
```

---

## 🚀 実行手順（フル自動化）

以下の順番でスクリプトを実行してください：

```bash
cd scripts/

# ① Amazon EFS の作成
./eks-create-efs.sh

# ② EKS クラスタの作成
./eks-create-cluster.sh

# ③ 監視環境（Prometheus / Grafana）のセットアップ
./0-monitoring-setup.sh

# ④ PVC作成 + Caliper設定ファイルのアップロード（EFSへ）
./1-4_setup.sh

# ⑤ Caliper Worker（100組織分）のデプロイ
./5-6_deploy-workers.sh

# ⑥ Caliper Manager のデプロイ（負荷試験の実行）
./7_deploy-manager.sh

# ⑦ 負荷試験レポートの取得（report.html）
./8_fetch-report.sh

# ⑧ クリーンアップ（Worker, Manager の削除）
./9_cleanup.sh
```

---

## 📊 Grafana ダッシュボード

- Grafana は NodePort 32000 番でアクセス可能（パスワード `admin`）
- Caliper TPS / ノードリソース / コンテナ使用量などを可視化

---

## 📦 依存ツール

- `eksctl`
- `kubectl`
- `helm`
- `aws` CLI
- EKS & EFS が利用可能な AWS アカウント

---

## 🛠 拡張のヒント

- S3へのレポート自動保存
- Argo Workflows によるCI化
- 各ORGごとのGrafanaダッシュボード分離表示

---



---

## 🔐 VPC セキュリティグループ連携と接続確認

### 1. セキュリティグループ連携（双方向）

```bash
cd scripts/
./efs-authorize-sg.sh
```

- `FABRIC_SG_ID` に、Fabricノードが属するSGを設定してください。
- CaliperクラスターとFabricノード間の**双方向通信（全ポート）**が許可されます。

### 2. Caliperノード → Fabricノード 接続確認

```bash
./caliper-test-connection.sh
```

- `FABRIC_PEER_HOST` に、Fabric PeerのVPC内ホスト名 or IP を指定してください。
- ポート7051などが開通しているかを `nc` で確認します。

---


---

## ☁️ S3へのレポートアップロード

試験レポートをS3バケットに保存するには以下を実行：

```bash
cd scripts/
./10_upload-report-to-s3.sh
```

- `your-s3-bucket-name` にアップロード先バケット名を設定してください
- 保存先パスは：`s3://<bucket>/caliper-reports/manager/report-YYYYMMDD-HHmmss.html`

AWS CLIが必要です。事前に`aws configure`などで認証設定してください。

---
