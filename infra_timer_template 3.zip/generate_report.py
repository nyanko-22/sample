import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime
import os

df = pd.read_csv("deploy_time.csv")

plt.figure(figsize=(10, 6))
plt.barh(df["Step"], df["Duration(s)"], color="skyblue")
plt.xlabel("Duration (seconds)")
plt.title("Deployment Script Duration")
plt.tight_layout()
os.makedirs("report", exist_ok=True)
plt.savefig("report/deploy_chart.png")
plt.close()

df_sorted = df.sort_values(by="Duration(s)", ascending=False)
df_sorted["Cumulative"] = df_sorted["Duration(s)"].cumsum()
df_sorted["Cumulative %"] = 100 * df_sorted["Cumulative"] / df_sorted["Duration(s)"].sum()

fig, ax1 = plt.subplots(figsize=(10, 6))
ax1.bar(df_sorted["Step"], df_sorted["Duration(s)"], color="lightcoral")
ax1.set_ylabel("Duration (seconds)", color="lightcoral")
ax1.set_xlabel("Script Step")
ax1.set_title("Pareto Chart of Deployment Duration")
ax2 = ax1.twinx()
ax2.plot(df_sorted["Step"], df_sorted["Cumulative %"], color="blue", marker="o", linestyle="--")
ax2.set_ylabel("Cumulative Percentage (%)", color="blue")
ax2.set_ylim(0, 110)
plt.tight_layout()
plt.savefig("report/pareto_chart.png")
plt.close()

today = datetime.now().strftime("%Y-%m-%d")
os.makedirs("deploy_history", exist_ok=True)
df.to_csv(f"deploy_history/deploy_time_{today}.csv", index=False)

records = []
for file in sorted(os.listdir("deploy_history")):
    if file.endswith(".csv") and file.startswith("deploy_time_"):
        date = file.replace("deploy_time_", "").replace(".csv", "")
        try:
            datetime.strptime(date, "%Y-%m-%d")
        except ValueError:
            continue
        df_hist = pd.read_csv(f"deploy_history/{file}")
        df_hist["Date"] = date
        records.append(df_hist)

if records:
    df_all = pd.concat(records, ignore_index=True)
    df_pivot = df_all.pivot_table(index="Date", columns="Step", values="Duration(s)", aggfunc="sum").fillna(0)
    df_pivot.plot(kind="area", stacked=True, figsize=(12, 6))
    plt.title("Deployment Duration Over Time (Stacked Area Chart)")
    plt.ylabel("Duration (seconds)")
    plt.xlabel("Date")
    plt.legend(title="Script", bbox_to_anchor=(1.05, 1), loc='upper left')
    plt.tight_layout()
    plt.savefig("report/deploy_area_chart.png")
    plt.close()

now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
with open("report/index.html", "w") as f:
    f.write(f"""
    <html>
    <head><title>Deployment Report</title></head>
    <body>
    <h2>📊 Deployment Duration Report</h2>
    <p><b>Generated:</b> {now}</p>

    <h3>📈 Duration Bar Chart</h3>
    <img src="deploy_chart.png" width="600"><br>

    <h3>📉 Pareto Chart</h3>
    <img src="pareto_chart.png" width="600"><br>

    <h3>📊 Deployment Duration Over Time</h3>
    <img src="deploy_area_chart.png" width="800"><br>

    <h3>📋 Detail Table</h3>
    <table border="1" cellpadding="5">
        <tr><th>Step</th><th>Duration (s)</th></tr>
        {''.join(f"<tr><td>{row['Step']}</td><td>{row['Duration(s)']}</td></tr>" for _, row in df.iterrows())}
    </table>
    </body>
    </html>
    """)
