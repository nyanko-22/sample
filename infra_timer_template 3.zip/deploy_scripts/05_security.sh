#!/bin/bash
echo 'Running 05_security.sh...'
sleep 5