#!/bin/bash
echo 'Running 04_cdk_init.sh...'
sleep 30