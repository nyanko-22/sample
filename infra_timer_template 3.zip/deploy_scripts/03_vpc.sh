#!/bin/bash
echo 'Running 03_vpc.sh...'
sleep 15