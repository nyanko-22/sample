#!/bin/bash
echo 'Running 01_network.sh...'
sleep 25