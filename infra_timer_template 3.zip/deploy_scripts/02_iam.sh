#!/bin/bash
echo 'Running 02_iam.sh...'
sleep 8