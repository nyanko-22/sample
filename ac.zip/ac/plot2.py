import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
import networkx as nx

# グラフレイアウト用
from networkx.drawing.nx_agraph import graphviz_layout  # ← ここ重要！

# フォント設定（Noto Sans JP）
font_path = '/Users/user/Library/Fonts/NotoSansJP-VariableFont_wght.ttf'
font_prop = fm.FontProperties(fname=font_path)

# 系統図の定義
G = nx.DiGraph()
G.add_edges_from([
    ("現状把握", "パレート図分析"),
    ("パレート図分析", "時間の多い手順"),
    ("時間の多い手順", "自動化"),
    ("自動化", "マシンスペック向上"),
    ("マシンスペック向上", "並列処理"),
    ("並列処理", "構築時間の最適化"),
])

# ✅ 綺麗な縦のツリー構造（top-to-bottom）にする
pos = graphviz_layout(G, prog='dot')

# 描画
plt.figure(figsize=(10, 6))
nx.draw_networkx_nodes(G, pos, node_size=3000, node_color='lightblue')
nx.draw_networkx_edges(G, pos, arrowstyle='->', arrowsize=20)

# ラベル描画（日本語対応）
for node, (x, y) in pos.items():
    plt.text(x, y, node, fontproperties=font_prop,
             horizontalalignment='center', verticalalignment='center',
             fontsize=12, weight='bold')

# タイトル
plt.title("構築時間短縮に向けた系統図", fontproperties=font_prop, fontsize=16)

plt.axis('off')
plt.tight_layout()
plt.show()
