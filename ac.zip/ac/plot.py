import matplotlib.pyplot as plt
import networkx as nx
import japanize_matplotlib

import matplotlib.font_manager as fm

# フォントファイルのパスを指定
font_path = '/Users/user/Library/Fonts/NotoSansJP-VariableFont_wght.ttf'
font_prop = fm.FontProperties(fname=font_path)


def draw_cause_effect_diagram(title, causes, filename):
    G = nx.DiGraph()
    G.add_node("構築時間が長い")
    pos = {"構築時間が長い": (4, 4)}

    y_base = 3.5
    x_major = 1

    i = 0
    for major in causes:
        major_pos = (x_major * (i + 1), y_base)
        G.add_node(major)
        G.add_edge(major, "構築時間が長い")
        pos[major] = major_pos
        j = 0
        for minor in causes[major]:
            minor_pos = (major_pos[0] - 0.3 + j * 0.6, y_base - 1)
            G.add_node(minor)
            G.add_edge(minor, major)
            pos[minor] = minor_pos
            for k, detail in enumerate(causes[major][minor]):
                detail_pos = (minor_pos[0], y_base - 2 - k * 0.5)
                G.add_node(detail)
                G.add_edge(detail, minor)
                pos[detail] = detail_pos
            j += 1
        i += 1

    plt.figure(figsize=(14, 8))
    nx.draw(G, pos, with_labels=True, arrows=False, node_size=3000,
            node_color='lightblue', font_size=10, font_weight='bold')
    plt.title(title, fontsize=14)
    plt.tight_layout()
    plt.savefig(filename)
    plt.show()

# 要因分析系統図
causes_analysis = {
    "手動手順": {
        "作業ミス": ["やり直しが発生する"],
        "操作検知": ["完了に気づかない"]
    },
    "自動処理": {
        "処理構造": ["プログラム構造が非効率"]
    },
    "マシンスペック": {
        "CPU/メモリ": ["リソース不足"],
        "ネットワーク": ["帯域が遅い"],
        "ディスク": ["I/O速度が遅い"]
    }
}

# 対策立案系統図
causes_countermeasures = {
    "手動手順": {
        "時間がかかる": ["フルオートの手順化", "ワンストップ化"]
    },
    "自動処理": {
        "遅い": ["プログラム構造をリファクタ", "並列処理化"]
    },
    "マシンスペック": {
        "性能不足": ["CPU・メモリ増強", "高速ディスクに変更"]
    }
}

# 実行
draw_cause_effect_diagram("構築時間が長い：要因分析系統図", causes_analysis, "analysis_diagram.png")
draw_cause_effect_diagram("構築時間短縮：対策立案系統図", causes_countermeasures, "countermeasure_diagram.png")
