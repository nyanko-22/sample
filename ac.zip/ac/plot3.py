import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
import networkx as nx
from networkx.drawing.nx_agraph import graphviz_layout

# 日本語フォント設定
font_path = '/Users/user/Library/Fonts/NotoSansJP-VariableFont_wght.ttf'
font_prop = fm.FontProperties(fname=font_path)

# グラフ定義
G = nx.DiGraph()

# ノードとエッジの定義
edges = [
    # 原因構造
    ("構築時間が長い", "手順が多い"),
    ("構築時間が長い", "スペックが低い"),
    ("構築時間が長い", "並列実行が不十分"),
    ("手順が多い", "手動操作が多い"),
    ("手順が多い", "自動化スクリプトが遅い"),
    ("スペックが低い", "メモリ不足"),
    ("スペックが低い", "CPU使用率高い"),
    ("並列実行が不十分", "同期処理がボトルネック"),
    ("手動操作が多い", "並列化できていない"),
    ("自動化スクリプトが遅い", "スペックに依存"),

    # 対策 + 深掘り（2段階）
    ("手動操作が多い", "手順の自動化"),
    ("手順の自動化", "Jenkins導入"),
    ("Jenkins導入", "CDKテンプレ化"),

    ("並列化できていない", "並列化スクリプト導入"),
    ("並列化スクリプト導入", "スレッド制御最適化"),

    ("自動化スクリプトが遅い", "高速化・非同期処理"),
    ("高速化・非同期処理", "非同期IO化"),

    ("スペックに依存", "ハードウェアスペック向上"),
    ("ハードウェアスペック向上", "EC2インスタンスタイプ変更"),

    ("メモリ不足", "メモリ容量増設"),
    ("CPU使用率高い", "CPUコア数増加"),

    ("同期処理がボトルネック", "非同期処理導入"),
    ("非同期処理導入", "タスク分割再設計"),
]

G.add_edges_from(edges)

# エッジラベル（コスト/工数）
# edge_labels = {
#     ("手順の自動化", "Jenkins導入"): "10人日",
#     ("Jenkins導入", "CDKテンプレ化"): "5人日",
#     ("並列化できていない", "並列化スクリプト導入"): "8人日",
#     ("並列化スクリプト導入", "スレッド制御最適化"): "2人日",
#     ("スペックに依存", "ハードウェアスペック向上"): "EC2月5千円増",
#     ("メモリ不足", "メモリ容量増設"): "2万円",
#     ("CPU使用率高い", "CPUコア数増加"): "インスタンス再設計",
#     ("高速化・非同期処理", "非同期IO化"): "3人日",
#     ("非同期処理導入", "タスク分割再設計"): "5人日",
# }
edge_labels = {
    ("手順の自動化", "Jenkins導入"): "10 person-days",
    ("Jenkins導入", "CDKテンプレ化"): "5 person-days",
    ("並列化できていない", "並列化スクリプト導入"): "8 person-days",
    ("並列化スクリプト導入", "スレッド制御最適化"): "2 person-days",
    ("スペックに依存", "ハードウェアスペック向上"): "5k JPY/month",
    ("メモリ不足", "メモリ容量増設"): "20k JPY",
    ("CPU使用率高い", "CPUコア数増加"): "re-architect",
    ("高速化・非同期処理", "非同期IO化"): "3 person-days",
    ("非同期処理導入", "タスク分割再設計"): "5 person-days",
}

# ノードの色分け：重要度 or 状態
node_colors = {
    "構築時間が長い": "red",
    "手順が多い": "blue",
    "スペックが低い": "blue",
    "並列実行が不十分": "blue",
    "手動操作が多い": "red",
    "自動化スクリプトが遅い": "red",
    "メモリ不足": "yellow",
    "CPU使用率高い": "yellow",
    "同期処理がボトルネック": "yellow",
    "並列化できていない": "red",
    "スペックに依存": "yellow",

    # 対策ノード
    "手順の自動化": "yellow",
    "Jenkins導入": "green",
    "CDKテンプレ化": "green",

    "並列化スクリプト導入": "yellow",
    "スレッド制御最適化": "green",

    "高速化・非同期処理": "yellow",
    "非同期IO化": "green",

    "ハードウェアスペック向上": "green",
    "EC2インスタンスタイプ変更": "green",

    "メモリ容量増設": "green",
    "CPUコア数増加": "yellow",

    "非同期処理導入": "yellow",
    "タスク分割再設計": "green",
}

# レイアウト
pos = graphviz_layout(G, prog='dot')

# 描画
plt.figure(figsize=(16, 12))

# ノード描画（色付き）
node_color_list = [node_colors.get(n, 'lightgrey') for n in G.nodes()]
nx.draw_networkx_nodes(G, pos, node_size=3000, node_color=node_color_list)
nx.draw_networkx_edges(G, pos, arrowstyle='->', arrowsize=20)

# ノードラベル（日本語対応）
for node, (x, y) in pos.items():
    plt.text(x, y, node, fontproperties=font_prop,
             horizontalalignment='center', verticalalignment='center',
             fontsize=11, weight='bold')

# エッジラベル
nx.draw_networkx_edge_labels(G, pos, edge_labels=edge_labels, font_size=10, font_family='sans-serif')

# タイトル
plt.title("構築時間が長い原因と対策の系統図（対策深掘り + コスト表示）", fontproperties=font_prop, fontsize=16)
plt.axis('off')
plt.tight_layout()
plt.show()


# 構築時間が長い
# ├─ 手順が多い
# │  ├─ 手動操作が多い ──▶ 手順の自動化
# │  │  └─ 並列化できていない ──▶ 並列化スクリプト導入
# │  └─ 自動化スクリプトが遅い ──▶ 高速化・非同期処理
# │     └─ スペックに依存 ──▶ ハードウェアスペック向上
# ├─ スペックが低い
# │  ├─ メモリ不足 ──▶ メモリ容量増設
# │  └─ CPU使用率高い ──▶ CPUコア数増加
# └─ 並列実行が不十分
#    └─ 同期処理がボトルネック ──▶ 非同期処理導入