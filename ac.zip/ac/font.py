import matplotlib.font_manager as fm

# インストール済みフォント一覧から、日本語フォントだけ抜粋
for font in fm.findSystemFonts(fontpaths=None, fontext='ttf'):
    if 'Noto' in font or 'CJK' in font:
        print(font)