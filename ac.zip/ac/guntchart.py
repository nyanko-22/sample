import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
import networkx as nx
from networkx.drawing.nx_agraph import graphviz_layout
import matplotlib.dates as mdates
from datetime import datetime, timedelta

# 日本語フォント
font_path = '/Users/user/Library/Fonts/NotoSansJP-VariableFont_wght.ttf'
font_prop = fm.FontProperties(fname=font_path)

# スケジュール（開始日, 日数）
schedule = {
    "Jenkins導入": ("2024-07-01", 10),
    "CDKテンプレ化": ("2024-07-15", 5),
    "並列化スクリプト導入": ("2024-07-05", 8),
    "スレッド制御最適化": ("2024-07-20", 2),
    "非同期IO化": ("2024-08-01", 3),
    "EC2インスタンスタイプ変更": ("2024-07-10", 1),
    "メモリ容量増設": ("2024-07-08", 1),
    "CPUコア数増加": ("2024-08-05", 2),
    "タスク分割再設計": ("2024-08-10", 5),
}

# ==============================
# 図1：対策系統図
# ==============================

# 対策系統図グラフ定義（略：前と同じ構成でOK）
G = nx.DiGraph()
G.add_edges_from([
    ("構築時間が長い", "手順が多い"),
    ("手順が多い", "手動操作が多い"),
    ("手動操作が多い", "手順の自動化"),
    ("手順の自動化", "Jenkins導入"),
    ("Jenkins導入", "CDKテンプレ化"),
    ("手動操作が多い", "並列化できていない"),
    ("並列化できていない", "並列化スクリプト導入"),
    ("並列化スクリプト導入", "スレッド制御最適化"),
    ("自動化スクリプトが遅い", "高速化・非同期処理"),
    ("高速化・非同期処理", "非同期IO化"),
    ("スペックに依存", "ハードウェアスペック向上"),
    ("ハードウェアスペック向上", "EC2インスタンスタイプ変更"),
    ("メモリ不足", "メモリ容量増設"),
    ("CPU使用率高い", "CPUコア数増加"),
    ("非同期処理導入", "タスク分割再設計")
])

# レイアウト
pos = graphviz_layout(G, prog='dot')

# 描画用に figure を2つに分割
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(16, 14), gridspec_kw={'height_ratios': [2, 1]})

# --- 上段：対策系統図 ---
node_colors = ['lightgreen' if node in schedule else 'lightblue' for node in G.nodes()]
nx.draw_networkx_nodes(G, pos, node_color=node_colors, node_size=3000, ax=ax1)
nx.draw_networkx_edges(G, pos, arrowstyle='->', arrowsize=20, ax=ax1)

# ノードラベル
for node, (x, y) in pos.items():
    ax1.text(x, y, node, fontproperties=font_prop,
             horizontalalignment='center', verticalalignment='center',
             fontsize=11, weight='bold')

ax1.set_title("対策系統図", fontproperties=font_prop, fontsize=16)
ax1.axis('off')

# ==============================
# 図2：ガントチャート
# ==============================

# スケジュールデータ加工
tasks = []
for i, (task, (start_str, duration)) in enumerate(schedule.items()):
    start = datetime.strptime(start_str, "%Y-%m-%d")
    end = start + timedelta(days=duration)
    tasks.append((i, task, start, end))

# タスクバーの描画
for i, task, start, end in tasks:
    ax2.barh(i, (end - start).days, left=start, height=0.5, color='skyblue')
    ax2.text(start + timedelta(days=0.5), i, task, fontproperties=font_prop, va='center', ha='left')

# 軸設定
ax2.set_yticks([])
ax2.xaxis.set_major_formatter(mdates.DateFormatter('%m/%d'))
ax2.set_xlabel("スケジュール")
ax2.set_title("対策スケジュール（ガントチャート）", fontproperties=font_prop, fontsize=16)
ax2.grid(True)

plt.tight_layout()
plt.show()
