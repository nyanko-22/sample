
variable "enable_nat_gateway" {
  description = "Enable NAT Gateway for internet access from private subnets"
  type        = bool
  default     = false
}
