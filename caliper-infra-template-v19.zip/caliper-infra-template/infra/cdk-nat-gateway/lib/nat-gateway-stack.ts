import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as ec2 from 'aws-cdk-lib/aws-ec2';

interface NatGatewayStackProps extends cdk.StackProps {
  vpcId: string;
  publicSubnetId: string;
  privateSubnetIds: string[];
}

export class NatGatewayStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props: NatGatewayStackProps) {
    super(scope, id, props);

    const vpc = ec2.Vpc.fromLookup(this, 'TargetVPC', {
      vpcId: props.vpcId
    });

    const publicSubnet = ec2.Subnet.fromSubnetId(this, 'PublicSubnet', props.publicSubnetId);

    const natEip = new ec2.CfnEIP(this, 'NATEIP', {
      domain: 'vpc',
      tags: [{ key: 'Name', value: 'CaliperNAT-EIP' }]
    });

    const natGateway = new ec2.CfnNatGateway(this, 'CaliperNATGateway', {
      allocationId: natEip.attrAllocationId,
      subnetId: publicSubnet.subnetId,
      tags: [{ key: 'Name', value: 'CaliperNATGateway' }]
    });

    const privateRouteTable = new ec2.CfnRouteTable(this, 'PrivateRouteTable', {
      vpcId: vpc.vpcId,
      tags: [{ key: 'Name', value: 'CaliperPrivateRT' }]
    });

    props.privateSubnetIds.forEach((subnetId, index) => {
      new ec2.CfnRouteTableAssociation(this, `PrivateSubnetAssoc${index}`, {
        subnetId,
        routeTableId: privateRouteTable.ref
      });
    });

    new ec2.CfnRoute(this, 'PrivateRoute', {
      routeTableId: privateRouteTable.ref,
      destinationCidrBlock: '0.0.0.0/0',
      natGatewayId: natGateway.ref
    });
  }
}
