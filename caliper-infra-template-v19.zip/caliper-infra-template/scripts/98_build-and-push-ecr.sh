#!/bin/bash

# カスタムCaliperイメージをECRにPush

AWS_REGION="ap-northeast-1"
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
REPO_NAME="caliper-custom"
IMAGE_NAME="${ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com/${REPO_NAME}:latest"

echo "📦 ビルド中..."
docker build -t caliper-custom ./docker

echo "🔐 ECRログイン中..."
aws ecr get-login-password --region ${AWS_REGION} | docker login --username AWS --password-stdin "${ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com"

echo "📁 ECRリポジトリを作成（存在しない場合）..."
aws ecr describe-repositories --repository-names "${REPO_NAME}" --region ${AWS_REGION} || aws ecr create-repository --repository-name "${REPO_NAME}" --region ${AWS_REGION}

echo "🚀 タグ付け & Push..."
docker tag caliper-custom:latest ${IMAGE_NAME}
docker push ${IMAGE_NAME}

echo "✅ 完了: ${IMAGE_NAME}"
