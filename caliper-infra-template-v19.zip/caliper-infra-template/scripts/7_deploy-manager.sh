#!/bin/bash
helm upgrade --install caliper-manager ../caliper-manager-chart \
  -f ../caliper-manager-chart/values.yaml
