#!/bin/bash
# scripts/10_upload-report-to-s3.sh

BUCKET_NAME="your-s3-bucket-name"  # ← S3バケット名を設定してください
REGION="ap-northeast-1"
ORG_ID="manager"
REPORT_FILE="/mnt/efs/configs/${ORG_ID}/report.html"

if [ ! -f "$REPORT_FILE" ]; then
  echo "❌ report.html が存在しません: $REPORT_FILE"
  exit 1
fi

TIMESTAMP=$(date +%Y%m%d-%H%M%S)
DEST_PATH="caliper-reports/${ORG_ID}/report-${TIMESTAMP}.html"

echo "☁️ S3へアップロード中: s3://${BUCKET_NAME}/${DEST_PATH}"
aws s3 cp "$REPORT_FILE" "s3://${BUCKET_NAME}/${DEST_PATH}" --region "$REGION"

if [ $? -eq 0 ]; then
  echo "✅ アップロード成功: https://${BUCKET_NAME}.s3.${REGION}.amazonaws.com/${DEST_PATH}"
else
  echo "❌ アップロード失敗"
fi
