#!/bin/bash
for i in $(seq -f "%03g" 1 100); do
  ORG_ID="org${i}"
  helm upgrade --install caliper-worker-${ORG_ID} ../caliper-worker-chart \
    -f ../caliper-worker-chart/values.yaml \
    -f ../caliper-worker-chart/values-orgs/${ORG_ID}.yaml
done
