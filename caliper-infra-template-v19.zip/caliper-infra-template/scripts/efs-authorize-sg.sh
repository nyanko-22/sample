#!/bin/bash
# scripts/efs-authorize-sg.sh

REGION=ap-northeast-1
FABRIC_SG_ID="sg-xxxxxxxxxxxxxxxxx"     # ← Fabricノードが所属しているSG
CALIPER_NODEGROUP_SG=$(aws ec2 describe-security-groups \
  --region $REGION \
  --filters Name=group-name,Values=eks-cluster-sg* \
  --query "SecurityGroups[0].GroupId" --output text)

echo "🌐 Fabric SG: $FABRIC_SG_ID"
echo "🔗 Caliper SG: $CALIPER_NODEGROUP_SG"

# Fabric SGからCaliperノードにアクセスを許可
aws ec2 authorize-security-group-ingress \
  --group-id $CALIPER_NODEGROUP_SG \
  --protocol -1 \
  --source-group $FABRIC_SG_ID \
  --region $REGION

# Caliper SGからFabricノードにアクセスを許可
aws ec2 authorize-security-group-ingress \
  --group-id $FABRIC_SG_ID \
  --protocol -1 \
  --source-group $CALIPER_NODEGROUP_SG \
  --region $REGION

echo "✅ 双方向通信のセキュリティグループ連携が完了しました"
