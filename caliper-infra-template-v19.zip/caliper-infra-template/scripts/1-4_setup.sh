#!/bin/bash
kubectl apply -k "github.com/kubernetes-sigs/aws-efs-csi-driver/deploy/kubernetes/overlays/stable/ecr/?ref=release-1.5"
kubectl apply -f ../k8s/pvc.yaml
kubectl apply -f ../k8s/init-efs-uploader.yaml
sleep 5
kubectl cp ../configs init-efs-uploader:/mnt/efs/
kubectl cp ../benchmarks init-efs-uploader:/mnt/efs/
kubectl delete pod init-efs-uploader
