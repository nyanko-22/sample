#!/bin/bash
# scripts/caliper-test-connection.sh

FABRIC_PEER_HOST="fabric-peer.example.com"  # ← Fabric Peerの内部DNS名 or IPに書き換え
PORT=7051

echo "📡 Fabric Peer 接続確認: $FABRIC_PEER_HOST:$PORT"

if nc -z -v -w5 $FABRIC_PEER_HOST $PORT; then
  echo "✅ 接続成功"
else
  echo "❌ 接続失敗"
fi
