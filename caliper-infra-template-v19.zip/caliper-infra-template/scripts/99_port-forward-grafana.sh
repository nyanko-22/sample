#!/bin/bash

# スクリプト名: scripts/99_port-forward-grafana.sh

NAMESPACE="monitoring"
SERVICE_NAME="grafana"
LOCAL_PORT=3000
REMOTE_PORT=3000

echo "🔍 Grafana Service を探しています..."

# Namespaceが指定されていない場合、defaultを試す
if ! kubectl get svc -n "$NAMESPACE" "$SERVICE_NAME" &> /dev/null; then
  echo "⚠️ monitoring namespace に grafana service が見つかりません。default namespace を試します..."
  NAMESPACE="default"
  if ! kubectl get svc -n "$NAMESPACE" "$SERVICE_NAME" &> /dev/null; then
    echo "❌ Grafana サービスが見つかりませんでした"
    exit 1
  fi
fi

echo "🚪 Grafana をローカルポート ${LOCAL_PORT} にフォワードします..."
echo "🌐 ブラウザで http://localhost:${LOCAL_PORT} を開いてください"
kubectl -n "$NAMESPACE" port-forward svc/"$SERVICE_NAME" ${LOCAL_PORT}:${REMOTE_PORT}
