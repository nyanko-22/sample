#!/bin/bash
# scripts/eks-create-efs.sh

REGION=ap-northeast-1
EFS_NAME=caliper-efs
SECURITY_GROUP_NAME=efs-sg
VPC_ID=$(aws ec2 describe-vpcs --region $REGION --query "Vpcs[0].VpcId" --output text)
CIDR_BLOCK=$(aws ec2 describe-vpcs --vpc-ids $VPC_ID --region $REGION --query "Vpcs[0].CidrBlock" --output text)

echo "🔧 VPC: $VPC_ID"
echo "🔧 CIDR: $CIDR_BLOCK"

# 1. セキュリティグループ作成
SG_ID=$(aws ec2 create-security-group \
  --group-name $SECURITY_GROUP_NAME \
  --description "EFS SG" \
  --vpc-id $VPC_ID \
  --region $REGION \
  --query "GroupId" --output text)

aws ec2 authorize-security-group-ingress \
  --group-id $SG_ID \
  --protocol tcp --port 2049 \
  --cidr $CIDR_BLOCK \
  --region $REGION

echo "✅ Security Group created: $SG_ID"

# 2. EFS作成
FILE_SYSTEM_ID=$(aws efs create-file-system \
  --creation-token $EFS_NAME \
  --performance-mode generalPurpose \
  --throughput-mode bursting \
  --region $REGION \
  --tags Key=Name,Value=$EFS_NAME \
  --query "FileSystemId" --output text)

echo "✅ EFS created: $FILE_SYSTEM_ID"

# 3. Subnetごとにマウントターゲット作成
SUBNET_IDS=$(aws ec2 describe-subnets \
  --filters "Name=vpc-id,Values=$VPC_ID" \
  --region $REGION \
  --query "Subnets[*].SubnetId" --output text)

for subnet_id in $SUBNET_IDS; do
  aws efs create-mount-target \
    --file-system-id $FILE_SYSTEM_ID \
    --subnet-id $subnet_id \
    --security-groups $SG_ID \
    --region $REGION
  echo "📌 Mount target created in subnet: $subnet_id"
done

echo "🎉 EFS setup complete: $FILE_SYSTEM_ID"
