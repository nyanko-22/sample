#!/bin/bash
# scripts/0-monitoring-setup.sh

helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
helm repo update

helm upgrade --install monitoring prometheus-community/kube-prometheus-stack \
  -f ../monitoring/kube-prometheus-values.yaml \
  --namespace monitoring --create-namespace
