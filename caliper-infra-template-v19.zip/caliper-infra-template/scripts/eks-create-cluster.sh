#!/bin/bash
# scripts/eks-create-cluster.sh (for existing VPC)

echo "🚀 Creating EKS cluster using existing VPC..."

eksctl create cluster -f ../k8s/eks-cluster-existing-vpc.yaml

echo "✅ EKS Cluster created: caliper-cluster"
