#!/bin/bash
POD=$(kubectl get pod -l app=caliper-manager -o jsonpath="{.items[0].metadata.name}")
kubectl cp ${POD}:/hyperledger/caliper/workspace/report.html ./report-$(date +%Y%m%d-%H%M%S).html
