#!/bin/bash
for i in $(seq -f "%03g" 1 100); do
  ORG_ID="org${i}"
  helm uninstall caliper-worker-${ORG_ID}
done
helm uninstall caliper-manager
